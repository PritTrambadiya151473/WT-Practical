// BookVerse -- JavaScript form validation
// Every form in the project is validated here (frontend only,
// nothing is actually submitted to a server).

const RX_NAME = /^[A-Za-z\s.'-]{2,50}$/;
const RX_EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const RX_PHONE = /^[6-9]\d{9}$/; // 10-digit Indian mobile format
const RX_PRICE = /^\d+(\.\d{1,2})?$/;

function setFieldState(input, feedbackEl, valid, message) {
  if (valid) {
    input.classList.remove("is-invalid");
    input.classList.add("is-valid");
  } else {
    input.classList.remove("is-valid");
    input.classList.add("is-invalid");
    if (feedbackEl) feedbackEl.textContent = message;
  }
  return valid;
}

function validateRequired(input, feedbackEl, label) {
  const ok = input.value.trim().length > 0;
  return setFieldState(input, feedbackEl, ok, `${label} is required.`);
}

/* ---------------- Contact form ---------------- */
function initContactForm() {
  const form = document.getElementById("contactForm");
  if (!form) return;

  const name = document.getElementById("cName");
  const email = document.getElementById("cEmail");
  const phone = document.getElementById("cPhone");
  const subject = document.getElementById("cSubject");
  const message = document.getElementById("cMessage");

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    let ok = true;

    ok = setFieldState(name, name.nextElementSibling,
      RX_NAME.test(name.value.trim()), "Enter a valid name (letters only, 2-50 chars).") && ok;

    ok = setFieldState(email, email.nextElementSibling,
      RX_EMAIL.test(email.value.trim()), "Enter a valid email address.") && ok;

    ok = setFieldState(phone, phone.nextElementSibling,
      RX_PHONE.test(phone.value.trim()), "Enter a valid 10-digit phone number.") && ok;

    ok = validateRequired(subject, subject.nextElementSibling, "Subject") && ok;
    ok = validateRequired(message, message.nextElementSibling, "Message") && ok;

    if (ok) {
      showToast("Message sent! We'll get back to you soon.", "success");
      form.reset();
      form.classList.remove("was-validated");
      [name, email, phone, subject, message].forEach((i) => i.classList.remove("is-valid"));
    } else {
      showToast("Please fix the highlighted fields.", "danger");
    }
  });
}

/* ---------------- Customer login form ---------------- */
function initCustomerLoginForm() {
  const form = document.getElementById("customerLoginForm");
  if (!form) return;
  const email = document.getElementById("loginEmail");
  const password = document.getElementById("loginPassword");
  // Fields are wrapped in .input-icon-group (for the left icon / eye
  // toggle), so the .invalid-feedback div is a sibling of the wrapper,
  // not of the input itself.
  const emailFeedback = email.closest(".input-icon-group")
    ? email.closest(".input-icon-group").nextElementSibling
    : email.nextElementSibling;
  const passwordFeedback = password.closest(".input-icon-group")
    ? password.closest(".input-icon-group").nextElementSibling
    : password.nextElementSibling;

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    let ok = true;
    ok = setFieldState(email, emailFeedback,
      RX_EMAIL.test(email.value.trim()), "Enter a valid email address.") && ok;
    ok = setFieldState(password, passwordFeedback,
      password.value.length >= 6, "Password must be at least 6 characters.") && ok;

    if (ok) {
      showToast("Logged in successfully! (demo only)", "success");
      setTimeout(() => (window.location.href = "index.html"), 900);
    } else {
      showToast("Please fix the highlighted fields.", "danger");
    }
  });
}

/* ---------------- Admin login form ---------------- */
// Fixed demo credentials -- this is still a frontend-only project (no real
// auth/backend), but the login now checks against a specific account
// instead of accepting any well-formed input.
const ADMIN_DEMO_USERNAME = "admin";
const ADMIN_DEMO_PASSWORD = "admin1234";

function initAdminLoginForm() {
  const form = document.getElementById("adminLoginForm");
  if (!form) return;
  const username = document.getElementById("adminUsername");
  const password = document.getElementById("adminPassword");

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    let ok = true;
    ok = validateRequired(username, username.nextElementSibling, "Username") && ok;
    ok = setFieldState(password, password.nextElementSibling,
      password.value.length >= 8, "Password must be at least 8 characters.") && ok;

    if (!ok) {
      showToast("Please fix the highlighted fields.", "danger");
      return;
    }

    const credsMatch = username.value.trim() === ADMIN_DEMO_USERNAME && password.value === ADMIN_DEMO_PASSWORD;
    if (!credsMatch) {
      setFieldState(username, username.nextElementSibling, false, "Incorrect username or password.");
      setFieldState(password, password.nextElementSibling, false, "Incorrect username or password.");
      showToast("Incorrect username or password.", "danger");
      return;
    }

    showToast("Welcome back, Admin! (demo only)", "success");
    setTimeout(() => (window.location.href = "dashboard.html"), 900);
  });
}

/* ---------------- Add Book form (admin) ---------------- */
function initAddBookForm() {
  const form = document.getElementById("addBookForm");
  if (!form) return;
  const name = document.getElementById("bookName");
  const author = document.getElementById("bookAuthor");
  const category = document.getElementById("bookCategory");
  const price = document.getElementById("bookPrice");
  const description = document.getElementById("bookDescription");
  const descCount = document.getElementById("bookDescCount");

  if (description && descCount) {
    description.addEventListener("input", () => {
      descCount.textContent = description.value.length;
    });
  }

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    let ok = true;
    ok = validateRequired(name, name.nextElementSibling, "Book name") && ok;
    ok = validateRequired(author, author.nextElementSibling, "Author") && ok;
    ok = setFieldState(category, category.nextElementSibling,
      category.value !== "", "Please select a category.") && ok;
    ok = setFieldState(price, price.closest(".input-group").nextElementSibling,
      RX_PRICE.test(price.value.trim()), "Enter a valid price (numbers only).") && ok;
    const priceFeedback = price.closest(".input-group").nextElementSibling;
    if (priceFeedback) priceFeedback.style.display = price.classList.contains("is-invalid") ? "block" : "none";
    ok = validateRequired(description, description.nextElementSibling, "Description") && ok;

    if (ok) {
      showToast(`"${name.value.trim()}" was added to the catalogue (demo only).`, "success");
      form.reset();
      [name, author, category, price, description].forEach((i) => i.classList.remove("is-valid"));
      if (descCount) descCount.textContent = "0";
      const preview = document.getElementById("bookImagePreview");
      const placeholder = document.getElementById("bookCoverPlaceholder");
      if (preview) preview.classList.add("d-none");
      if (placeholder) placeholder.classList.remove("d-none");
    } else {
      showToast("Please fix the highlighted fields.", "danger");
    }
  });

  const fileInput = document.getElementById("bookImage");
  if (fileInput) {
    fileInput.addEventListener("change", () => {
      const preview = document.getElementById("bookImagePreview");
      const placeholder = document.getElementById("bookCoverPlaceholder");
      if (!preview || !fileInput.files[0]) return;
      const reader = new FileReader();
      reader.onload = (ev) => {
        preview.src = ev.target.result;
        preview.classList.remove("d-none");
        if (placeholder) placeholder.classList.add("d-none");
      };
      reader.readAsDataURL(fileInput.files[0]);
    });
  }
}

/* ---------------- Admin profile / password change ---------------- */
function initProfileForm() {
  const form = document.getElementById("profileForm");
  if (form) {
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      showToast("Profile updated (demo only).", "success");
    });
  }
  const pwForm = document.getElementById("changePasswordForm");
  if (pwForm) {
    const current = document.getElementById("currentPassword");
    const next = document.getElementById("newPassword");
    const confirm = document.getElementById("confirmPassword");
    pwForm.addEventListener("submit", (e) => {
      e.preventDefault();
      let ok = true;
      ok = validateRequired(current, current.nextElementSibling, "Current password") && ok;
      ok = setFieldState(next, next.nextElementSibling,
        next.value.length >= 8, "New password must be at least 8 characters.") && ok;
      ok = setFieldState(confirm, confirm.nextElementSibling,
        confirm.value === next.value && confirm.value.length > 0, "Passwords do not match.") && ok;
      if (ok) {
        showToast("Password changed (demo only).", "success");
        pwForm.reset();
        [current, next, confirm].forEach((i) => i.classList.remove("is-valid"));
      } else {
        showToast("Please fix the highlighted fields.", "danger");
      }
    });
  }
}

/* ---------------- Register form ---------------- */
function initRegisterForm() {
  const form = document.getElementById("registerForm");
  if (!form) return;

  const name = document.getElementById("regFullName");
  const email = document.getElementById("regEmail");
  const password = document.getElementById("regPassword");
  const confirmPassword = document.getElementById("regConfirmPassword");
  const phone = document.getElementById("regPhone");
  const terms = document.getElementById("regTerms");

  const RX_PASSWORD = /^(?=.*[A-Za-z])(?=.*\d).{8,}$/;

  const feedbackFor = (input) =>
    input.closest(".input-icon-group")
      ? input.closest(".input-icon-group").nextElementSibling
      : input.nextElementSibling;

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    let ok = true;

    ok = setFieldState(name, feedbackFor(name),
      RX_NAME.test(name.value.trim()), "Enter a valid name (letters only, 2-50 chars).") && ok;

    ok = setFieldState(email, feedbackFor(email),
      RX_EMAIL.test(email.value.trim()), "Enter a valid email address.") && ok;

    ok = setFieldState(password, feedbackFor(password),
      RX_PASSWORD.test(password.value), "At least 8 characters with letters and numbers.") && ok;

    ok = setFieldState(confirmPassword, feedbackFor(confirmPassword),
      confirmPassword.value === password.value && confirmPassword.value.length > 0,
      "Passwords do not match.") && ok;

    // Phone is optional -- only validate the format if something was typed.
    if (phone.value.trim().length > 0) {
      ok = setFieldState(phone, feedbackFor(phone),
        RX_PHONE.test(phone.value.trim()), "Enter a valid 10-digit phone number.") && ok;
    } else {
      phone.classList.remove("is-invalid", "is-valid");
    }

    const termsFeedback = terms.closest(".form-check").querySelector(".invalid-feedback");
    ok = setFieldState(terms, termsFeedback, terms.checked, "Please accept the terms to continue.") && ok;

    if (ok) {
      showToast("Account created! (demo only)", "success");
      setTimeout(() => (window.location.href = "login.html"), 900);
    } else {
      showToast("Please fix the highlighted fields.", "danger");
    }
  });
}

document.addEventListener("DOMContentLoaded", () => {
  initContactForm();
  initCustomerLoginForm();
  initAdminLoginForm();
  initAddBookForm();
  initProfileForm();
  initRegisterForm();
});
