// BookVerse -- shared dataset (static / dummy data, no backend)

const BOOKS = [
  {
    "id": 1,
    "title": "The Silent Compiler",
    "author": "R. K. Mehta",
    "category": "Programming",
    "price": 499,
    "rating": 4.5,
    "stock": true,
    "img": "images/books/book1.svg",
    "description": "A witty deep-dive into the discipline of writing code that compiles quietly and fails loudly only when it matters.",
    "bestseller": true
  },
  {
    "id": 2,
    "title": "Java in the Shadows",
    "author": "Ananya Rao",
    "category": "Java",
    "price": 399,
    "rating": 4.2,
    "stock": true,
    "img": "images/books/book2.svg",
    "description": "An atmospheric tour of the JVM, threading, and the quiet corners of enterprise Java most tutorials skip.",
    "bestseller": false
  },
  {
    "id": 3,
    "title": "Python for Wanderers",
    "author": "S. Iyer",
    "category": "Python",
    "price": 349,
    "rating": 4.7,
    "stock": true,
    "img": "images/books/book3.svg",
    "description": "A gentle, story-driven path through Python idioms, decorators, and the itch to automate everything.",
    "bestseller": true
  },
  {
    "id": 4,
    "title": "HTML Foundations",
    "author": "D. Kapoor",
    "category": "HTML",
    "price": 249,
    "rating": 4.0,
    "stock": true,
    "img": "images/books/book4.svg",
    "description": "A clean, example-first primer on semantic HTML5 and the structure that holds every page together.",
    "bestseller": false
  },
  {
    "id": 5,
    "title": "CSS: Ink & Layout",
    "author": "Priya Nair",
    "category": "CSS",
    "price": 279,
    "rating": 4.3,
    "stock": true,
    "img": "images/books/book5.svg",
    "description": "A designer's field notes on the cascade, specificity, and the layouts that finally make sense.",
    "bestseller": false
  },
  {
    "id": 6,
    "title": "JavaScript Alchemy",
    "author": "Vikram Sethi",
    "category": "JavaScript",
    "price": 459,
    "rating": 4.6,
    "stock": true,
    "img": "images/books/book6.svg",
    "description": "An energetic walk through closures, promises, and the async patterns that power modern the web.",
    "bestseller": true
  },
  {
    "id": 7,
    "title": "C++ Under the Lamp",
    "author": "N. Bose",
    "category": "C++",
    "price": 529,
    "rating": 4.1,
    "stock": false,
    "img": "images/books/book7.svg",
    "description": "A patient, low-light guide to memory, pointers, and the discipline C++ still rewards.",
    "bestseller": false
  },
  {
    "id": 8,
    "title": "Databases: A Field Guide",
    "author": "Meera Joshi",
    "category": "Database",
    "price": 389,
    "rating": 4.4,
    "stock": true,
    "img": "images/books/book8.svg",
    "description": "A practical map of relational design, indexing, and the queries that hold real systems together.",
    "bestseller": false
  },
  {
    "id": 9,
    "title": "Networks Unbound",
    "author": "Arjun Malhotra",
    "category": "Networking",
    "price": 419,
    "rating": 3.9,
    "stock": true,
    "img": "images/books/book9.svg",
    "description": "A traveller's guide to protocols, routing, and the invisible plumbing behind every request.",
    "bestseller": false
  },
  {
    "id": 10,
    "title": "Artificial Minds",
    "author": "Kavya Menon",
    "category": "AI",
    "price": 599,
    "rating": 4.8,
    "stock": true,
    "img": "images/books/book10.svg",
    "description": "A curious, plainly-written introduction to models, training loops, and how machines start to generalise.",
    "bestseller": true
  },
  {
    "id": 11,
    "title": "The Web Weaver's Notebook",
    "author": "Rohit Verma",
    "category": "Web Development",
    "price": 449,
    "rating": 4.5,
    "stock": true,
    "img": "images/books/book11.svg",
    "description": "A working notebook for building responsive, accessible sites from a blank folder to a shipped site.",
    "bestseller": true
  },
  {
    "id": 12,
    "title": "Learning Java Slowly",
    "author": "Ishaan Kapoor",
    "category": "Java",
    "price": 329,
    "rating": 4.0,
    "stock": true,
    "img": "images/books/book12.svg",
    "description": "A slow, careful reintroduction to Java for readers who want the fundamentals to actually stick.",
    "bestseller": false
  },
  {
    "id": 13,
    "title": "Python Patterns",
    "author": "Sneha Pillai",
    "category": "Python",
    "price": 369,
    "rating": 4.4,
    "stock": true,
    "img": "images/books/book13.svg",
    "description": "A pattern library for Python developers who want their code to read like well-set prose.",
    "bestseller": false
  },
  {
    "id": 14,
    "title": "Beyond the Tag: HTML5",
    "author": "Aditya Chauhan",
    "category": "HTML",
    "price": 259,
    "rating": 3.8,
    "stock": false,
    "img": "images/books/book14.svg",
    "description": "A modern refresher on semantic markup, forms, and the accessibility wins hiding in plain HTML.",
    "bestseller": false
  },
  {
    "id": 15,
    "title": "Responsive by Design",
    "author": "Tanvi Shah",
    "category": "CSS",
    "price": 299,
    "rating": 4.2,
    "stock": true,
    "img": "images/books/book15.svg",
    "description": "A breakpoint-by-breakpoint guide to building layouts that hold up on any screen.",
    "bestseller": false
  },
  {
    "id": 16,
    "title": "Async Everything",
    "author": "Farhan Ali",
    "category": "JavaScript",
    "price": 479,
    "rating": 4.6,
    "stock": true,
    "img": "images/books/book16.svg",
    "description": "A hands-on tour of callbacks, async/await, and the event loop underneath it all.",
    "bestseller": false
  },
  {
    "id": 17,
    "title": "Pointers & Ponders",
    "author": "Devika Rao",
    "category": "C++",
    "price": 559,
    "rating": 4.0,
    "stock": false,
    "img": "images/books/book17.svg",
    "description": "A methodical companion to pointers, references, and the memory model that trips up beginners.",
    "bestseller": false
  },
  {
    "id": 18,
    "title": "SQL for Storytellers",
    "author": "Nikhil Bansal",
    "category": "Database",
    "price": 359,
    "rating": 4.3,
    "stock": true,
    "img": "images/books/book18.svg",
    "description": "A story-driven introduction to joins, normalization, and writing SQL you can explain later.",
    "bestseller": false
  },
  {
    "id": 19,
    "title": "Ports, Packets & Paths",
    "author": "Ritu Dubey",
    "category": "Networking",
    "price": 399,
    "rating": 3.7,
    "stock": true,
    "img": "images/books/book19.svg",
    "description": "A ground-level look at subnets, DNS, and the handshakes that make networks work.",
    "bestseller": false
  },
  {
    "id": 20,
    "title": "Machines That Dream",
    "author": "Omkar Deshpande",
    "category": "AI",
    "price": 649,
    "rating": 4.9,
    "stock": true,
    "img": "images/books/book20.svg",
    "description": "An accessible survey of neural networks, datasets, and the questions worth asking before training one.",
    "bestseller": true
  }
];

const REVIEWS = [
  {
    "name": "Aarav Shah",
    "text": "Ordered three programming books and they arrived exactly as described. The category filters made finding what I needed effortless.",
    "rating": 5,
    "role": "Backend Developer"
  },
  {
    "name": "Diya Patel",
    "text": "The book details page told me everything I needed before buying, description, stock, even a sense of the cover design.",
    "rating": 4,
    "role": "CS Student"
  },
  {
    "name": "Kabir Singh",
    "text": "Best online bookstore experience I have had for technical titles. Checkout was quick and the cart summary was crystal clear.",
    "rating": 5,
    "role": "Software Engineer"
  },
  {
    "name": "Meera Iyer",
    "text": "I like that they curate by category properly instead of dumping everything into one long list. Found my AI reading list in minutes.",
    "rating": 4,
    "role": "Data Analyst"
  }
];

const ORDERS = [
  {
    "id": "ORD-1042",
    "customer": "Aarav Shah",
    "book": "Machines That Dream",
    "qty": 1,
    "amount": 649,
    "status": "Delivered",
    "date": "17 May 2026"
  },
  {
    "id": "ORD-1043",
    "customer": "Diya Patel",
    "book": "CSS: Ink & Layout",
    "qty": 2,
    "amount": 558,
    "status": "Shipped",
    "date": "16 May 2026"
  },
  {
    "id": "ORD-1044",
    "customer": "Kabir Singh",
    "book": "The Silent Compiler",
    "qty": 1,
    "amount": 499,
    "status": "Pending",
    "date": "15 May 2026"
  },
  {
    "id": "ORD-1045",
    "customer": "Meera Iyer",
    "book": "Python Patterns",
    "qty": 1,
    "amount": 369,
    "status": "Delivered",
    "date": "15 May 2026"
  },
  {
    "id": "ORD-1046",
    "customer": "Rohan Gupta",
    "book": "Pointers & Ponders",
    "qty": 1,
    "amount": 559,
    "status": "Cancelled",
    "date": "14 May 2026"
  }
];

const USERS = [
  {
    "name": "Aarav Shah",
    "email": "aarav.shah@example.com",
    "phone": "9820011223",
    "city": "Mumbai"
  },
  {
    "name": "Diya Patel",
    "email": "diya.patel@example.com",
    "phone": "9830022334",
    "city": "Ahmedabad"
  },
  {
    "name": "Kabir Singh",
    "email": "kabir.singh@example.com",
    "phone": "9840033445",
    "city": "Delhi"
  },
  {
    "name": "Meera Iyer",
    "email": "meera.iyer@example.com",
    "phone": "9850044556",
    "city": "Chennai"
  },
  {
    "name": "Rohan Gupta",
    "email": "rohan.gupta@example.com",
    "phone": "9860055667",
    "city": "Pune"
  }
];
