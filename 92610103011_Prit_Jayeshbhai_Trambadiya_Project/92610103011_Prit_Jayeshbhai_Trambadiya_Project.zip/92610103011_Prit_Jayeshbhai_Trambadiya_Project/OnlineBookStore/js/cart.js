// BookVerse -- cart management
// Cart lives in localStorage as an array of { id, qty }.
// Frontend-only demo: nothing is sent to a server.

const CART_KEY = "cbv_cart";

function getCart() {
  try {
    return JSON.parse(localStorage.getItem(CART_KEY) || "[]");
  } catch (e) {
    return [];
  }
}

function saveCart(cart) {
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
  updateCartBadge();
}

function updateCartBadge() {
  const count = getCart().reduce((s, i) => s + i.qty, 0);
  document.querySelectorAll(".cart-badge").forEach((badge) => {
    badge.textContent = count;
  });
}

function addToCart(bookId, qty = 1) {
  const book = BOOKS.find((b) => b.id === bookId);
  if (!book || !book.stock) {
    showToast("Sorry, that title is out of stock.", "danger");
    return;
  }
  const cart = getCart();
  const existing = cart.find((i) => i.id === bookId);
  if (existing) {
    existing.qty += qty;
  } else {
    cart.push({ id: bookId, qty });
  }
  saveCart(cart);
  showToast(`Added "${book.title}" to cart.`, "success");
}

function removeFromCart(bookId) {
  const cart = getCart().filter((i) => i.id !== bookId);
  saveCart(cart);
  renderCartPage();
}

function setCartQty(bookId, qty) {
  const cart = getCart();
  const item = cart.find((i) => i.id === bookId);
  if (!item) return;
  item.qty = Math.max(1, Math.min(qty, 20));
  saveCart(cart);
  renderCartPage();
}

function cartTotal() {
  const cart = getCart();
  return cart.reduce((sum, item) => {
    const book = BOOKS.find((b) => b.id === item.id);
    return book ? sum + book.price * item.qty : sum;
  }, 0);
}

function renderCartPage() {
  const list = document.getElementById("cartList");
  const emptyState = document.getElementById("cartEmptyState");
  const summary = document.getElementById("cartSummaryBox");
  if (!list) return;

  const cart = getCart();

  if (cart.length === 0) {
    list.innerHTML = "";
    if (emptyState) emptyState.classList.remove("d-none");
    if (summary) summary.classList.add("d-none");
    return;
  }

  if (emptyState) emptyState.classList.add("d-none");
  if (summary) summary.classList.remove("d-none");

  list.innerHTML = cart
    .map((item) => {
      const book = BOOKS.find((b) => b.id === item.id);
      if (!book) return "";
      const lineTotal = book.price * item.qty;
      return `
      <div class="cart-row d-flex align-items-center gap-3 mb-3 flex-wrap">
        <img src="${book.img}" alt="${book.title}">
        <div class="flex-grow-1">
          <h3 class="h6 mb-1 font-display">${book.title}</h3>
          <div class="small text-muted">by ${book.author}</div>
          <div class="fw-bold text-brass">Rs. ${book.price}</div>
        </div>
        <div class="qty-control">
          <button type="button" aria-label="Decrease quantity" onclick="setCartQty(${book.id}, ${item.qty - 1})">-</button>
          <input type="text" value="${item.qty}" readonly aria-label="Quantity">
          <button type="button" aria-label="Increase quantity" onclick="setCartQty(${book.id}, ${item.qty + 1})">+</button>
        </div>
        <div class="fw-bold" style="min-width:90px; text-align:right;">Rs. ${lineTotal}</div>
        <button class="btn btn-outline-danger btn-sm" onclick="removeFromCart(${book.id})" aria-label="Remove ${book.title} from cart">
          <i class="bi bi-trash3"></i>
        </button>
      </div>`;
    })
    .join("");

  const subtotal = cartTotal();
  const shipping = subtotal > 0 && subtotal < 500 ? 49 : 0;
  const total = subtotal + shipping;

  const subtotalEl = document.getElementById("cartSubtotal");
  const shippingEl = document.getElementById("cartShipping");
  const totalEl = document.getElementById("cartGrandTotal");
  if (subtotalEl) subtotalEl.textContent = `Rs. ${subtotal}`;
  if (shippingEl) shippingEl.textContent = shipping === 0 ? "Free" : `Rs. ${shipping}`;
  if (totalEl) totalEl.textContent = `Rs. ${total}`;
}

function checkoutCart() {
  const cart = getCart();
  if (cart.length === 0) return;
  const modalEl = document.getElementById("checkoutModal");
  if (modalEl && window.bootstrap) {
    new bootstrap.Modal(modalEl).show();
  } else {
    showToast("Order placed! (demo only)", "success");
  }
  localStorage.removeItem(CART_KEY);
  updateCartBadge();
  setTimeout(renderCartPage, 300);
}

document.addEventListener("DOMContentLoaded", () => {
  updateCartBadge();
  renderCartPage();
  const checkoutBtn = document.getElementById("checkoutBtn");
  if (checkoutBtn) checkoutBtn.addEventListener("click", checkoutCart);
});
