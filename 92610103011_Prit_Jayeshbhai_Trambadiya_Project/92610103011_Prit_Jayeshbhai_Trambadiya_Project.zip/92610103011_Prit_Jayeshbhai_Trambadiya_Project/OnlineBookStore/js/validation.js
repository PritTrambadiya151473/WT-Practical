// BookVerse -- JavaScript form validation
// Frontend-only: nothing is submitted to a server.
//
// Every form follows the same pattern:
//   1. Read the values the user typed.
//   2. Check each field in order: required -> length/range -> pattern.
//   3. Show the error under the field (red border) or mark it valid (green).
//   4. Only continue (toast / redirect) when every check passed.

// ============================================================
// Shared regular expressions
// ============================================================
var RX_NAME     = /^[A-Za-z]+(?:[ .'-]+[A-Za-z]+)*\.?$/;               // letters, spaces, . ' - (e.g. "R. K. Mehta")
var RX_EMAIL    = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/;
var RX_PHONE    = /^[6-9]\d{9}$/;                                      // 10-digit Indian mobile
var RX_USERNAME = /^[A-Za-z0-9_]{4,15}$/;                              // letters, numbers, underscore
var RX_PASSWORD = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&#]).+$/; // upper, lower, digit, special
var RX_PRICE    = /^\d+(\.\d{1,2})?$/;

var PASSWORD_PATTERN_MSG =
  "Password needs an uppercase letter, a lowercase letter, a digit " +
  "and a special character (@$!%*?&#).";

// ============================================================
// Helpers
// ============================================================

// Helper: show an error message under a field
function showError(inputId, errorId, message) {
  document.getElementById(errorId).textContent = message;
  var el = document.getElementById(inputId);
  el.classList.add("invalid");
  el.classList.remove("valid");
}

// Helper: clear the error message of a field and mark it valid
function clearError(inputId, errorId) {
  document.getElementById(errorId).textContent = "";
  var el = document.getElementById(inputId);
  el.classList.remove("invalid");
  el.classList.add("valid");
}

// Helper: wipe a field back to its neutral state (used after reset / for empty optional fields)
function resetField(inputId, errorId) {
  var el = document.getElementById(inputId);
  if (!el) return;
  el.classList.remove("invalid", "valid");
  var err = document.getElementById(errorId);
  if (err) err.textContent = "";
}

// Helper: today's date as yyyy-mm-dd in the visitor's local time
function todayString() {
  var d = new Date();
  var mm = String(d.getMonth() + 1).padStart(2, "0");
  var dd = String(d.getDate()).padStart(2, "0");
  return d.getFullYear() + "-" + mm + "-" + dd;
}

// ============================================================
// Contact form (contact.html)
// Logic 1: All fields are required
// Logic 2: Full name pattern (letters and spaces only, 2-50 characters)
// Logic 3: Email pattern
// Logic 4: Phone number pattern (10-digit Indian mobile number)
// Logic 5: Subject minimum length (3 characters)
// Logic 6: Message length (10 - 500 characters)
// ============================================================
function initContactForm() {
  var form = document.getElementById("contactForm");
  if (!form) return;

  form.addEventListener("submit", function (event) {
    event.preventDefault();
    var isValid = true;

    var name    = document.getElementById("cName").value.trim();
    var email   = document.getElementById("cEmail").value.trim();
    var phone   = document.getElementById("cPhone").value.trim();
    var subject = document.getElementById("cSubject").value.trim();
    var message = document.getElementById("cMessage").value.trim();

    // ---- Full name ----
    if (name === "") {
      showError("cName", "cNameError", "Full name is required.");               // Logic 1
      isValid = false;
    } else if (name.length < 2 || name.length > 50 || !RX_NAME.test(name)) {
      showError("cName", "cNameError", "Name must be 2-50 letters (spaces allowed).");  // Logic 2
      isValid = false;
    } else { clearError("cName", "cNameError"); }

    // ---- Email ----
    if (email === "") {
      showError("cEmail", "cEmailError", "Email address is required.");         // Logic 1
      isValid = false;
    } else if (!RX_EMAIL.test(email)) {
      showError("cEmail", "cEmailError", "Enter a valid email address (e.g. name@example.com)."); // Logic 3
      isValid = false;
    } else { clearError("cEmail", "cEmailError"); }

    // ---- Phone ----
    if (phone === "") {
      showError("cPhone", "cPhoneError", "Phone number is required.");          // Logic 1
      isValid = false;
    } else if (!RX_PHONE.test(phone)) {
      showError("cPhone", "cPhoneError",
        "Enter a valid 10-digit mobile number starting with 6, 7, 8 or 9.");    // Logic 4
      isValid = false;
    } else { clearError("cPhone", "cPhoneError"); }

    // ---- Subject ----
    if (subject === "") {
      showError("cSubject", "cSubjectError", "Subject is required.");           // Logic 1
      isValid = false;
    } else if (subject.length < 3) {
      showError("cSubject", "cSubjectError", "Subject must be at least 3 characters long."); // Logic 5
      isValid = false;
    } else { clearError("cSubject", "cSubjectError"); }

    // ---- Message ----
    if (message === "") {
      showError("cMessage", "cMessageError", "Message is required.");           // Logic 1
      isValid = false;
    } else if (message.length < 10 || message.length > 500) {
      showError("cMessage", "cMessageError", "Message must be between 10 and 500 characters."); // Logic 6
      isValid = false;
    } else { clearError("cMessage", "cMessageError"); }

    if (isValid) {
      showToast("Message sent! We'll get back to you soon.", "success");
      form.reset();
      ["cName", "cEmail", "cPhone", "cSubject", "cMessage"].forEach(function (id) {
        resetField(id, id + "Error");
      });
    } else {
      showToast("Please fix the highlighted fields.", "danger");
    }
  });
}

// ============================================================
// Customer login form (login.html)
// Logic 1: All fields are required
// Logic 2: Email pattern
// Logic 3: Password length (minimum 8 characters)
// Logic 4: Password pattern (upper, lower, digit, special char)
// ============================================================
function initCustomerLoginForm() {
  var form = document.getElementById("customerLoginForm");
  if (!form) return;

  form.addEventListener("submit", function (event) {
    event.preventDefault();
    var isValid = true;

    var email = document.getElementById("loginEmail").value.trim();
    var password = document.getElementById("loginPassword").value;

    // ---- Email ----
    if (email === "") {
      showError("loginEmail", "loginEmailError", "Email address is required.");  // Logic 1
      isValid = false;
    } else if (!RX_EMAIL.test(email)) {
      showError("loginEmail", "loginEmailError", "Enter a valid email address (e.g. name@example.com)."); // Logic 2
      isValid = false;
    } else { clearError("loginEmail", "loginEmailError"); }

    // ---- Password ----
    if (password === "") {
      showError("loginPassword", "loginPasswordError", "Password is required."); // Logic 1
      isValid = false;
    } else if (password.length < 8) {
      showError("loginPassword", "loginPasswordError",
        "Password must be at least 8 characters long.");                         // Logic 3
      isValid = false;
    } else if (!RX_PASSWORD.test(password)) {
      showError("loginPassword", "loginPasswordError", PASSWORD_PATTERN_MSG);    // Logic 4
      isValid = false;
    } else { clearError("loginPassword", "loginPasswordError"); }

    if (isValid) {
      showToast("Logged in successfully! (demo only)", "success");
      setTimeout(function () { window.location.href = "index.html"; }, 900);
    } else {
      showToast("Please fix the highlighted fields.", "danger");
    }
  });
}

// ============================================================
// Register form (register.html)
// Logic 1: Name, email, password and confirm password are required
// Logic 2: Full name pattern (letters and spaces only, 2-50 characters)
// Logic 3: Email pattern
// Logic 4: Password length (minimum 8 characters)
// Logic 5: Password pattern (upper, lower, digit, special char)
// Logic 6: Confirm password must match the password
// Logic 7: Phone (optional) - 10-digit Indian mobile number if entered
// Logic 8: Date of birth (optional) - cannot be in the future
// Logic 9: Terms & Conditions must be accepted
// ============================================================
function initRegisterForm() {
  var form = document.getElementById("registerForm");
  if (!form) return;

  form.addEventListener("submit", function (event) {
    event.preventDefault();
    var isValid = true;

    var name     = document.getElementById("regFullName").value.trim();
    var email    = document.getElementById("regEmail").value.trim();
    var password = document.getElementById("regPassword").value;
    var confirm  = document.getElementById("regConfirmPassword").value;
    var phone    = document.getElementById("regPhone").value.trim();
    var dob      = document.getElementById("regDob").value;
    var terms    = document.getElementById("regTerms").checked;

    // ---- Full name ----
    if (name === "") {
      showError("regFullName", "regFullNameError", "Full name is required.");    // Logic 1
      isValid = false;
    } else if (name.length < 2 || name.length > 50 || !RX_NAME.test(name)) {
      showError("regFullName", "regFullNameError", "Name must be 2-50 letters (spaces allowed)."); // Logic 2
      isValid = false;
    } else { clearError("regFullName", "regFullNameError"); }

    // ---- Email ----
    if (email === "") {
      showError("regEmail", "regEmailError", "Email address is required.");      // Logic 1
      isValid = false;
    } else if (!RX_EMAIL.test(email)) {
      showError("regEmail", "regEmailError", "Enter a valid email address (e.g. name@example.com)."); // Logic 3
      isValid = false;
    } else { clearError("regEmail", "regEmailError"); }

    // ---- Password ----
    if (password === "") {
      showError("regPassword", "regPasswordError", "Password is required.");     // Logic 1
      isValid = false;
    } else if (password.length < 8) {
      showError("regPassword", "regPasswordError", "Password must be at least 8 characters long."); // Logic 4
      isValid = false;
    } else if (!RX_PASSWORD.test(password)) {
      showError("regPassword", "regPasswordError", PASSWORD_PATTERN_MSG);        // Logic 5
      isValid = false;
    } else { clearError("regPassword", "regPasswordError"); }

    // ---- Confirm password ----
    if (confirm === "") {
      showError("regConfirmPassword", "regConfirmPasswordError", "Please confirm your password."); // Logic 1
      isValid = false;
    } else if (confirm !== password) {
      showError("regConfirmPassword", "regConfirmPasswordError", "Passwords do not match."); // Logic 6
      isValid = false;
    } else { clearError("regConfirmPassword", "regConfirmPasswordError"); }

    // ---- Phone (optional) ----
    if (phone === "") {
      resetField("regPhone", "regPhoneError");
    } else if (!RX_PHONE.test(phone)) {
      showError("regPhone", "regPhoneError",
        "Enter a valid 10-digit mobile number starting with 6, 7, 8 or 9.");     // Logic 7
      isValid = false;
    } else { clearError("regPhone", "regPhoneError"); }

    // ---- Date of birth (optional) ----
    if (dob === "") {
      resetField("regDob", "regDobError");
    } else if (dob > todayString()) {
      showError("regDob", "regDobError", "Date of birth cannot be in the future."); // Logic 8
      isValid = false;
    } else { clearError("regDob", "regDobError"); }

    // ---- Terms ----
    if (!terms) {
      showError("regTerms", "regTermsError", "Please accept the terms to continue."); // Logic 9
      isValid = false;
    } else { clearError("regTerms", "regTermsError"); }

    if (isValid) {
      showToast("Account created! (demo only)", "success");
      setTimeout(function () { window.location.href = "login.html"; }, 900);
    } else {
      showToast("Please fix the highlighted fields.", "danger");
    }
  });
}

// ============================================================
// Admin login form (admin/admin-login.html)
// Logic 1: All fields are required
// Logic 2: Username pattern (letters, numbers, underscore, 4-15 characters)
// Logic 3: Password length (minimum 8 characters)
// Logic 4: Credentials must match the demo admin account
// ============================================================
var ADMIN_DEMO_USERNAME = "admin";
var ADMIN_DEMO_PASSWORD = "admin1234";

function initAdminLoginForm() {
  var form = document.getElementById("adminLoginForm");
  if (!form) return;

  form.addEventListener("submit", function (event) {
    event.preventDefault();
    var isValid = true;

    var username = document.getElementById("adminUsername").value.trim();
    var password = document.getElementById("adminPassword").value;

    // ---- Username ----
    if (username === "") {
      showError("adminUsername", "adminUsernameError", "Username is required.");  // Logic 1
      isValid = false;
    } else if (!RX_USERNAME.test(username)) {
      showError("adminUsername", "adminUsernameError",
        "Username must be 4-15 characters (letters, numbers, underscore only)."); // Logic 2
      isValid = false;
    } else { clearError("adminUsername", "adminUsernameError"); }

    // ---- Password ----
    if (password === "") {
      showError("adminPassword", "adminPasswordError", "Password is required.");  // Logic 1
      isValid = false;
    } else if (password.length < 8) {
      showError("adminPassword", "adminPasswordError",
        "Password must be at least 8 characters long.");                          // Logic 3
      isValid = false;
    } else { clearError("adminPassword", "adminPasswordError"); }

    if (!isValid) {
      showToast("Please fix the highlighted fields.", "danger");
      return;
    }

    // Logic 4: check the demo credentials
    if (username !== ADMIN_DEMO_USERNAME || password !== ADMIN_DEMO_PASSWORD) {
      showError("adminUsername", "adminUsernameError", "Incorrect username or password.");
      showError("adminPassword", "adminPasswordError", "Incorrect username or password.");
      showToast("Incorrect username or password.", "danger");
      return;
    }

    showToast("Welcome back, Admin! (demo only)", "success");
    setTimeout(function () { window.location.href = "dashboard.html"; }, 900);
  });
}

// ============================================================
// Add Book form (admin/add-book.html)
// Logic 1: All fields are required
// Logic 2: Book name length (2 - 100 characters)
// Logic 3: Author pattern (letters, spaces, . ' - only)
// Logic 4: A category must be selected
// Logic 5: Price pattern (number, max 2 decimals) and range (1 - 100000)
// Logic 6: Description length (10 - 500 characters)
// ============================================================
function initAddBookForm() {
  var form = document.getElementById("addBookForm");
  if (!form) return;

  var descInput = document.getElementById("bookDescription");
  var descCount = document.getElementById("bookDescCount");
  if (descInput && descCount) {
    descInput.addEventListener("input", function () {
      descCount.textContent = descInput.value.length;
    });
  }

  form.addEventListener("submit", function (event) {
    event.preventDefault();
    var isValid = true;

    var name     = document.getElementById("bookName").value.trim();
    var author   = document.getElementById("bookAuthor").value.trim();
    var category = document.getElementById("bookCategory").value;
    var price    = document.getElementById("bookPrice").value.trim();
    var desc     = document.getElementById("bookDescription").value.trim();

    // ---- Book name ----
    if (name === "") {
      showError("bookName", "bookNameError", "Book name is required.");           // Logic 1
      isValid = false;
    } else if (name.length < 2 || name.length > 100) {
      showError("bookName", "bookNameError", "Book name must be 2-100 characters long."); // Logic 2
      isValid = false;
    } else { clearError("bookName", "bookNameError"); }

    // ---- Author ----
    if (author === "") {
      showError("bookAuthor", "bookAuthorError", "Author is required.");          // Logic 1
      isValid = false;
    } else if (!RX_NAME.test(author)) {
      showError("bookAuthor", "bookAuthorError", "Author name can contain letters, spaces, . ' and - only."); // Logic 3
      isValid = false;
    } else { clearError("bookAuthor", "bookAuthorError"); }

    // ---- Category ----
    if (category === "") {
      showError("bookCategory", "bookCategoryError", "Please select a category.");  // Logic 1 / 4
      isValid = false;
    } else { clearError("bookCategory", "bookCategoryError"); }

    // ---- Price ----
    if (price === "") {
      showError("bookPrice", "bookPriceError", "Price is required.");             // Logic 1
      isValid = false;
    } else if (!RX_PRICE.test(price) || Number(price) < 1 || Number(price) > 100000) {
      showError("bookPrice", "bookPriceError",
        "Enter a valid price between 1 and 100000 (up to 2 decimals).");          // Logic 5
      isValid = false;
    } else { clearError("bookPrice", "bookPriceError"); }

    // ---- Description ----
    if (desc === "") {
      showError("bookDescription", "bookDescriptionError", "Description is required."); // Logic 1
      isValid = false;
    } else if (desc.length < 10) {
      showError("bookDescription", "bookDescriptionError",
        "Description must be at least 10 characters long.");                      // Logic 6
      isValid = false;
    } else { clearError("bookDescription", "bookDescriptionError"); }

    if (isValid) {
      showToast('"' + name + '" was added to the catalogue (demo only).', "success");
      form.reset();
      ["bookName", "bookAuthor", "bookCategory", "bookPrice", "bookDescription"].forEach(function (id) {
        resetField(id, id + "Error");
      });
      if (descCount) descCount.textContent = "0";
      var preview = document.getElementById("bookImagePreview");
      var placeholder = document.getElementById("bookCoverPlaceholder");
      if (preview) preview.classList.add("d-none");
      if (placeholder) placeholder.classList.remove("d-none");
    } else {
      showToast("Please fix the highlighted fields.", "danger");
    }
  });

  // Cover image preview (not validated - optional)
  var fileInput = document.getElementById("bookImage");
  if (fileInput) {
    fileInput.addEventListener("change", function () {
      var preview = document.getElementById("bookImagePreview");
      var placeholder = document.getElementById("bookCoverPlaceholder");
      if (!preview || !fileInput.files[0]) return;
      var reader = new FileReader();
      reader.onload = function (ev) {
        preview.src = ev.target.result;
        preview.classList.remove("d-none");
        if (placeholder) placeholder.classList.add("d-none");
      };
      reader.readAsDataURL(fileInput.files[0]);
    });
  }
}

// ============================================================
// Admin profile (admin/profile.html)
//
// Profile details form
//   Logic 1: All fields are required
//   Logic 2: Name pattern (letters and spaces only, 2-50 characters)
//   Logic 3: Email pattern
//   Logic 4: Mobile pattern (10-digit Indian mobile number)
//
// Change password form
//   Logic 1: All fields are required
//   Logic 5: New password length (minimum 8 characters)
//   Logic 6: New password pattern (upper, lower, digit, special char)
//   Logic 7: New password must differ from the current password
//   Logic 8: Confirm password must match the new password
// ============================================================
function initProfileForm() {
  var form = document.getElementById("profileForm");
  if (form) {
    form.addEventListener("submit", function (event) {
      event.preventDefault();
      var isValid = true;

      var name   = document.getElementById("profileName").value.trim();
      var email  = document.getElementById("profileEmail").value.trim();
      var mobile = document.getElementById("profileMobile").value.trim();

      if (name === "") {
        showError("profileName", "profileNameError", "Name is required.");        // Logic 1
        isValid = false;
      } else if (name.length < 2 || name.length > 50 || !RX_NAME.test(name)) {
        showError("profileName", "profileNameError", "Name must be 2-50 letters (spaces allowed)."); // Logic 2
        isValid = false;
      } else { clearError("profileName", "profileNameError"); }

      if (email === "") {
        showError("profileEmail", "profileEmailError", "Email address is required."); // Logic 1
        isValid = false;
      } else if (!RX_EMAIL.test(email)) {
        showError("profileEmail", "profileEmailError", "Enter a valid email address (e.g. name@example.com)."); // Logic 3
        isValid = false;
      } else { clearError("profileEmail", "profileEmailError"); }

      if (mobile === "") {
        showError("profileMobile", "profileMobileError", "Mobile number is required."); // Logic 1
        isValid = false;
      } else if (!RX_PHONE.test(mobile)) {
        showError("profileMobile", "profileMobileError",
          "Enter a valid 10-digit mobile number starting with 6, 7, 8 or 9.");   // Logic 4
        isValid = false;
      } else { clearError("profileMobile", "profileMobileError"); }

      if (isValid) {
        showToast("Profile updated (demo only).", "success");
      } else {
        showToast("Please fix the highlighted fields.", "danger");
      }
    });
  }

  var pwForm = document.getElementById("changePasswordForm");
  if (pwForm) {
    pwForm.addEventListener("submit", function (event) {
      event.preventDefault();
      var isValid = true;

      var current = document.getElementById("currentPassword").value;
      var next    = document.getElementById("newPassword").value;
      var confirm = document.getElementById("confirmPassword").value;

      // ---- Current password ----
      if (current === "") {
        showError("currentPassword", "currentPasswordError", "Current password is required."); // Logic 1
        isValid = false;
      } else { clearError("currentPassword", "currentPasswordError"); }

      // ---- New password ----
      if (next === "") {
        showError("newPassword", "newPasswordError", "New password is required.");  // Logic 1
        isValid = false;
      } else if (next.length < 8) {
        showError("newPassword", "newPasswordError", "Password must be at least 8 characters long."); // Logic 5
        isValid = false;
      } else if (!RX_PASSWORD.test(next)) {
        showError("newPassword", "newPasswordError", PASSWORD_PATTERN_MSG);          // Logic 6
        isValid = false;
      } else if (next === current) {
        showError("newPassword", "newPasswordError",
          "New password must be different from the current password.");              // Logic 7
        isValid = false;
      } else { clearError("newPassword", "newPasswordError"); }

      // ---- Confirm password ----
      if (confirm === "") {
        showError("confirmPassword", "confirmPasswordError", "Please confirm your new password."); // Logic 1
        isValid = false;
      } else if (confirm !== next) {
        showError("confirmPassword", "confirmPasswordError", "Passwords do not match."); // Logic 8
        isValid = false;
      } else { clearError("confirmPassword", "confirmPasswordError"); }

      if (isValid) {
        showToast("Password changed (demo only).", "success");
        pwForm.reset();
        ["currentPassword", "newPassword", "confirmPassword"].forEach(function (id) {
          resetField(id, id + "Error");
        });
      } else {
        showToast("Please fix the highlighted fields.", "danger");
      }
    });
  }
}

document.addEventListener("DOMContentLoaded", function () {
  initContactForm();
  initCustomerLoginForm();
  initAdminLoginForm();
  initAddBookForm();
  initProfileForm();
  initRegisterForm();
});
