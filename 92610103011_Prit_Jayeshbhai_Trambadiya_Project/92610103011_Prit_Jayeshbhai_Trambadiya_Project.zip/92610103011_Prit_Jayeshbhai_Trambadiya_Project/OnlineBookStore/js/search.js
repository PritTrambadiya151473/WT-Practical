// BookVerse -- catalogue rendering, search and category filter
// All book data comes from the static BOOKS array in data.js.

const CATEGORY_ICONS = {
  "Programming": "bi-code-slash",
  "HTML": "bi-filetype-html",
  "CSS": "bi-filetype-css",
  "JavaScript": "bi-filetype-js",
  "Java": "bi-cup-hot",
  "Python": "bi-file-earmark-code",
  "C++": "bi-braces",
  "Database": "bi-database",
  "Networking": "bi-hdd-network",
  "AI": "bi-cpu",
  "Web Development": "bi-globe",
};

function getParam(name) {
  return new URLSearchParams(window.location.search).get(name);
}

function starRating(rating) {
  const full = Math.round(rating);
  let out = "";
  for (let i = 0; i < 5; i++) out += i < full ? '<i class="bi bi-star-fill"></i>' : '<i class="bi bi-star"></i>';
  return out;
}

function bookCardHTML(book) {
  return `
  <div class="col-sm-6 col-lg-4 col-xl-3">
    <div class="book-card">
      ${book.bestseller ? '<span class="stamp">Best<br>Seller</span>' : ""}
      <a href="book-details.html?id=${book.id}" class="cover-wrap d-block">
        <img src="${book.img}" alt="Cover of ${book.title}">
      </a>
      ${!book.stock ? '<div class="out-of-stock">Out of Stock</div>' : ""}
      <div class="body">
        <div class="cat-tag">${book.category}</div>
        <h3><a href="book-details.html?id=${book.id}" class="text-reset">${book.title}</a></h3>
        <div class="author">by ${book.author}</div>
        <div class="price-row">
          <span class="price">Rs. ${book.price}</span>
          <span class="rating" title="${book.rating} out of 5">${starRating(book.rating)}</span>
        </div>
        <button class="btn btn-brass btn-sm w-100 mt-3" ${!book.stock ? "disabled" : ""}
          onclick="addToCart(${book.id})">
          <i class="bi bi-basket3 me-1"></i> Add to Cart
        </button>
      </div>
    </div>
  </div>`;
}

function renderGrid(containerId, books, emptyMessage = "No books found.") {
  const el = document.getElementById(containerId);
  if (!el) return;
  if (books.length === 0) {
    el.innerHTML = `<div class="col-12 text-center py-5 text-muted">
      <i class="bi bi-emoji-frown fs-1 d-block mb-2 text-brass"></i>${emptyMessage}
    </div>`;
    return;
  }
  el.innerHTML = books.map(bookCardHTML).join("");
}

/* ---------------- Home page sections ---------------- */
function renderHomeSections() {
  const featured = document.getElementById("featuredBooksGrid");
  if (featured) renderGrid("featuredBooksGrid", BOOKS.filter((b) => b.bestseller).slice(0, 4));

  const latest = document.getElementById("latestBooksGrid");
  if (latest) renderGrid("latestBooksGrid", [...BOOKS].sort((a, b) => b.id - a.id).slice(0, 4));

  const bestSellers = document.getElementById("bestSellersGrid");
  if (bestSellers) renderGrid("bestSellersGrid", BOOKS.filter((b) => b.bestseller));

  const catGrid = document.getElementById("homeCategoriesGrid");
  if (catGrid) renderCategoryCards("homeCategoriesGrid", 6);

  const reviewsGrid = document.getElementById("reviewsGrid");
  if (reviewsGrid) {
    reviewsGrid.innerHTML = REVIEWS.map(
      (r) => `
      <div class="col-md-6 col-lg-3">
        <div class="review-card">
          <span class="quote-mark">&ldquo;</span>
          <p class="small">${r.text}</p>
          <div class="rating mb-2">${starRating(r.rating)}</div>
          <div class="fw-bold">${r.name}</div>
          <div class="small text-muted">${r.role}</div>
        </div>
      </div>`
    ).join("");
  }
}

function renderCategoryCards(containerId, limit) {
  const el = document.getElementById(containerId);
  if (!el) return;
  const cats = [...new Set(BOOKS.map((b) => b.category))];
  const list = limit ? cats.slice(0, limit) : cats;
  el.innerHTML = list
    .map((cat) => {
      const count = BOOKS.filter((b) => b.category === cat).length;
      const icon = CATEGORY_ICONS[cat] || "bi-book";
      return `
      <div class="col-6 col-sm-4 col-lg-3">
        <a href="books.html?category=${encodeURIComponent(cat)}" class="text-decoration-none">
          <div class="category-card">
            <i class="bi ${icon}"></i>
            <span>${cat}</span>
            <small class="text-muted">${count} titles</small>
          </div>
        </a>
      </div>`;
    })
    .join("");
}

/* ---------------- Books listing page ---------------- */
function initBooksPage() {
  const grid = document.getElementById("booksGrid");
  if (!grid) return;

  const searchInput = document.getElementById("booksSearchInput");
  const sortSelect = document.getElementById("booksSortSelect");
  const tabsWrap = document.getElementById("categoryTabs");
  const resultCount = document.getElementById("resultCount");

  let activeCategory = getParam("category") || "All";
  const initialQuery = getParam("q") || "";
  if (searchInput) searchInput.value = initialQuery;

  const categories = ["All", ...new Set(BOOKS.map((b) => b.category))];
  if (tabsWrap) {
    tabsWrap.innerHTML = categories
      .map(
        (c) => `<button type="button" class="shelf-tab ${c === activeCategory ? "active" : ""}" data-cat="${c}">${c}</button>`
      )
      .join("");
    tabsWrap.querySelectorAll(".shelf-tab").forEach((btn) => {
      btn.addEventListener("click", () => {
        activeCategory = btn.dataset.cat;
        tabsWrap.querySelectorAll(".shelf-tab").forEach((b) => b.classList.remove("active"));
        btn.classList.add("active");
        apply();
      });
    });
  }

  function apply() {
    const q = (searchInput ? searchInput.value : "").trim().toLowerCase();
    let list = BOOKS.filter((b) => {
      const matchesCat = activeCategory === "All" || b.category === activeCategory;
      const matchesQuery =
        !q || b.title.toLowerCase().includes(q) || b.author.toLowerCase().includes(q) || b.category.toLowerCase().includes(q);
      return matchesCat && matchesQuery;
    });

    const sortVal = sortSelect ? sortSelect.value : "default";
    if (sortVal === "price-asc") list.sort((a, b) => a.price - b.price);
    else if (sortVal === "price-desc") list.sort((a, b) => b.price - a.price);
    else if (sortVal === "rating") list.sort((a, b) => b.rating - a.rating);
    else if (sortVal === "name") list.sort((a, b) => a.title.localeCompare(b.title));

    renderGrid("booksGrid", list, "No books match your search. Try a different keyword or category.");
    if (resultCount) resultCount.textContent = `${list.length} book${list.length === 1 ? "" : "s"} found`;
  }

  if (searchInput) searchInput.addEventListener("input", apply);
  if (sortSelect) sortSelect.addEventListener("change", apply);

  apply();
}

/* ---------------- Categories page ---------------- */
function initCategoriesPage() {
  const grid = document.getElementById("allCategoriesGrid");
  if (!grid) return;
  renderCategoryCards("allCategoriesGrid", null);
}

/* ---------------- Book details page ---------------- */
function initBookDetailsPage() {
  const wrap = document.getElementById("bookDetailsWrap");
  if (!wrap) return;
  const id = parseInt(getParam("id"), 10);
  const book = BOOKS.find((b) => b.id === id) || BOOKS[0];

  const originalPrice = Math.round((book.price * 1.25) / 5) * 5;
  const discountPct = Math.round((1 - book.price / originalPrice) * 100);

  document.title = `${book.title} - BookVerse`;
  wrap.innerHTML = `
    <div class="col-md-5">
      <div class="details-cover">
        <span class="details-cover-badge"><i class="bi bi-star-fill"></i> ${book.rating}</span>
        <img src="${book.img}" alt="Cover of ${book.title}" class="img-fluid">
      </div>
    </div>
    <div class="col-md-7">
      <div class="cat-tag mb-2">${book.category}</div>
      <h1 class="mb-1">${book.title}</h1>
      <p class="text-muted fst-italic mb-3">by ${book.author}</p>
      <div class="d-flex align-items-center gap-3 mb-3">
        <span class="rating fs-5">${starRating(book.rating)}</span>
        <span class="small text-muted">${book.rating} out of 5</span>
        <span class="stock-pill ${book.stock ? "in" : "out"}">${book.stock ? "In Stock" : "Out of Stock"}</span>
      </div>
      <p>${book.description}</p>
      <div class="price-block mb-4">
        <span class="price-now">Rs. ${book.price}</span>
        <span class="price-was">Rs. ${originalPrice}</span>
        <span class="price-discount">${discountPct}% off</span>
      </div>
      <div class="d-flex align-items-center gap-3 flex-wrap mb-4">
        <div class="qty-control">
          <button type="button" id="dtlQtyMinus" aria-label="Decrease quantity">-</button>
          <input type="text" id="dtlQty" value="1" readonly aria-label="Quantity">
          <button type="button" id="dtlQtyPlus" aria-label="Increase quantity">+</button>
        </div>
        <button class="btn btn-brass px-4" id="dtlAddToCart" ${!book.stock ? "disabled" : ""}>
          <i class="bi bi-basket3 me-1"></i> Add to Cart
        </button>
        <button class="wishlist-btn" id="dtlWishlist" aria-label="Add to wishlist" type="button">
          <i class="bi bi-heart"></i>
        </button>
      </div>
      <div class="details-perks">
        <div class="details-perk"><i class="bi bi-truck"></i><span>Free shipping on orders above Rs. 500</span></div>
        <div class="details-perk"><i class="bi bi-arrow-repeat"></i><span>7-day easy returns</span></div>
        <div class="details-perk"><i class="bi bi-shield-check"></i><span>Secure demo checkout</span></div>
      </div>
    </div>`;

  let qty = 1;
  const qtyInput = document.getElementById("dtlQty");
  document.getElementById("dtlQtyMinus").addEventListener("click", () => {
    qty = Math.max(1, qty - 1);
    qtyInput.value = qty;
  });
  document.getElementById("dtlQtyPlus").addEventListener("click", () => {
    qty = Math.min(20, qty + 1);
    qtyInput.value = qty;
  });
  document.getElementById("dtlAddToCart").addEventListener("click", () => addToCart(book.id, qty));
  const wishlistBtn = document.getElementById("dtlWishlist");
  wishlistBtn.addEventListener("click", () => {
    wishlistBtn.classList.toggle("is-active");
    wishlistBtn.querySelector("i").className = wishlistBtn.classList.contains("is-active") ? "bi bi-heart-fill" : "bi bi-heart";
    showToast(wishlistBtn.classList.contains("is-active") ? "Added to wishlist." : "Removed from wishlist.", "success");
  });

  const relatedGrid = document.getElementById("relatedBooksGrid");
  if (relatedGrid) {
    const related = BOOKS.filter((b) => b.category === book.category && b.id !== book.id).slice(0, 4);
    renderGrid("relatedBooksGrid", related, "");
  }
}

document.addEventListener("DOMContentLoaded", () => {
  renderHomeSections();
  initBooksPage();
  initCategoriesPage();
  initBookDetailsPage();
});
