// BookVerse -- general site behaviour
// Back to top button, dark mode toggle, and a small toast helper
// used across the contact/login/admin forms.

document.addEventListener("DOMContentLoaded", () => {
  initBackToTop();
  initDarkMode();
  initPasswordToggles();
});

function initBackToTop() {
  // The button itself is injected by renderClientFooter(), so poll briefly
  // until it exists, then wire it up.
  const attach = () => {
    const btn = document.getElementById("backToTop");
    if (!btn) return false;
    window.addEventListener("scroll", () => {
      btn.style.display = window.scrollY > 400 ? "flex" : "none";
    });
    btn.addEventListener("click", () => {
      window.scrollTo({ top: 0, behavior: "smooth" });
    });
    return true;
  };
  if (!attach()) {
    const timer = setInterval(() => {
      if (attach()) clearInterval(timer);
    }, 150);
  }
}

function initDarkMode() {
  const toggle = document.getElementById("darkModeToggle");
  const saved = localStorage.getItem("cbv_dark_mode");
  if (saved === "on") document.body.classList.add("dark-mode");
  if (!toggle) return;
  toggle.checked = document.body.classList.contains("dark-mode");
  toggle.addEventListener("change", () => {
    document.body.classList.toggle("dark-mode", toggle.checked);
    localStorage.setItem("cbv_dark_mode", toggle.checked ? "on" : "off");
  });
}

/**
 * Wires up any eye-icon button that toggles a password field between
 * masked and plain text. Markup contract: the button carries
 * data-toggle-password="<input id>".
 */
function initPasswordToggles() {
  document.querySelectorAll("[data-toggle-password]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const input = document.getElementById(btn.dataset.togglePassword);
      if (!input) return;
      const nowShowing = input.type === "password";
      input.type = nowShowing ? "text" : "password";
      btn.innerHTML = nowShowing ? '<i class="bi bi-eye-slash"></i>' : '<i class="bi bi-eye"></i>';
      btn.setAttribute("aria-label", nowShowing ? "Hide password" : "Show password");
    });
  });
}

/**
 * Show a small dismissible toast in the top-right corner.
 * type: "success" | "danger" | "warning" | "info"
 */
function showToast(message, type = "success") {
  let stack = document.querySelector(".toast-stack");
  if (!stack) {
    stack = document.createElement("div");
    stack.className = "toast-stack";
    document.body.appendChild(stack);
  }
  const el = document.createElement("div");
  el.className = `alert alert-${type} shadow-sm mb-2`;
  el.style.minWidth = "260px";
  el.textContent = message;
  stack.appendChild(el);
  setTimeout(() => {
    el.style.transition = "opacity 0.4s ease";
    el.style.opacity = "0";
    setTimeout(() => el.remove(), 400);
  }, 2600);
}
