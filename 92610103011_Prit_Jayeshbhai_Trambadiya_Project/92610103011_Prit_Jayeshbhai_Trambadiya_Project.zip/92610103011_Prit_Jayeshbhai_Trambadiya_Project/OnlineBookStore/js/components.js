// BookVerse -- shared layout components
// Injects the client navbar/footer or the admin sidebar/topbar
// into placeholder elements, so every page doesn't repeat the markup.

const CLIENT_NAV_LINKS = [
  { href: "index.html", label: "Home", icon: "bi-house" },
  { href: "books.html", label: "Books", icon: "bi-book" },
  { href: "categories.html", label: "Categories", icon: "bi-grid" },
  { href: "about.html", label: "About", icon: "bi-info-circle" },
  { href: "contact.html", label: "Contact", icon: "bi-envelope" },
];

function currentPage() {
  const path = window.location.pathname.split("/").pop() || "index.html";
  return path;
}

function navBasePath() {
  return window.location.pathname.includes("/admin/") ? "../" : "";
}

function cartCount() {
  try {
    const cart = JSON.parse(localStorage.getItem("cbv_cart") || "[]");
    return cart.reduce((sum, item) => sum + item.qty, 0);
  } catch (e) {
    return 0;
  }
}

function renderClientNavbar(basePath) {
  const mount = document.getElementById("navbar-placeholder");
  if (!mount) return;
  const base = basePath !== undefined ? basePath : navBasePath();
  const page = currentPage();
  const links = CLIENT_NAV_LINKS.map(
    (l) => `<li class="nav-item">
      <a class="nav-link ${page === l.href ? "active" : ""}" href="${base}${l.href}">
        <i class="bi ${l.icon}" aria-hidden="true"></i>${l.label}
      </a>
    </li>`
  ).join("");

  mount.innerHTML = `
  <nav class="navbar navbar-expand-lg site-navbar sticky-top py-3">
    <div class="container">
      <a class="navbar-brand" href="${base}index.html">
        <img src="${base}images/logo.svg" alt="BookVerse logo">
      </a>
      <div class="d-flex align-items-center gap-2 gap-lg-3 order-lg-3 ms-lg-4">
        <a href="${base}cart.html" class="navbar-icon-btn d-none d-lg-inline-block me-lg-1" aria-label="View cart">
          <i class="bi bi-basket3"></i>
          <span class="cart-badge" id="cartCountBadgeDesktop">${cartCount()}</span>
        </a>
        <a href="${base}login.html" class="btn btn-brass btn-sm px-4 py-2 d-none d-lg-inline-block">Login</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#mainNav" aria-controls="mainNav" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
      </div>
      <div class="offcanvas offcanvas-end site-mobile-nav" tabindex="-1" id="mainNav" aria-labelledby="mainNavLabel">
        <div class="offcanvas-header">
          <a class="navbar-brand mb-0" href="${base}index.html">
            <img src="${base}images/logo.svg" alt="BookVerse logo" style="height:32px;">
          </a>
          <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
          <form class="d-flex mx-lg-auto my-0 mb-4 mb-lg-0 my-lg-0" style="max-width:360px;width:100%;" role="search" onsubmit="return false;">
            <input class="form-control me-2 py-2" id="navSearchInput" type="search" placeholder="Search books, authors...">
            <button class="btn btn-outline-ink" type="button" onclick="performNavSearch()"><i class="bi bi-search"></i></button>
          </form>
          <ul class="navbar-nav mobile-nav-list align-items-lg-center gap-lg-2 ms-lg-3">
            ${links}
          </ul>
          <div class="mobile-nav-footer d-flex d-lg-none align-items-center justify-content-between gap-3 mt-4 pt-3">
            <a href="${base}cart.html" class="navbar-icon-btn d-inline-flex align-items-center gap-2 text-decoration-none" aria-label="View cart">
              <i class="bi bi-basket3 fs-5"></i>
              <span class="cart-badge" id="cartCountBadge">${cartCount()}</span>
              <span class="fw-semibold small cart-label">Cart</span>
            </a>
            <a href="${base}login.html" class="btn btn-brass px-4 flex-grow-1 text-center">Login</a>
          </div>
        </div>
      </div>
    </div>
  </nav>`;
}

function performNavSearch() {
  const q = document.getElementById("navSearchInput").value.trim();
  const base = navBasePath();
  const url = q ? `${base}books.html?q=${encodeURIComponent(q)}` : `${base}books.html`;
  window.location.href = url;
}

function renderClientFooter(basePath) {
  const mount = document.getElementById("footer-placeholder");
  if (!mount) return;
  const base = basePath !== undefined ? basePath : navBasePath();
  const adminLoginHref = base === "../" ? "admin-login.html" : `${base}admin/admin-login.html`;
  mount.innerHTML = `
  <footer class="site-footer pt-5 pb-3 mt-5">
    <div class="container">
      <div class="row g-4">
        <div class="col-lg-4">
          <img src="${base}images/logo-light.svg" alt="BookVerse" style="height:44px;" class="mb-3">
          <p class="small">A reading-room for people who still like the weight of a good technical book. Curated categories, honest descriptions, no clutter.</p>
          <div class="d-flex gap-2 mt-3">
            <a href="#" class="social-circle" aria-label="Facebook"><i class="bi bi-facebook"></i></a>
            <a href="#" class="social-circle" aria-label="Instagram"><i class="bi bi-instagram"></i></a>
            <a href="#" class="social-circle" aria-label="Twitter"><i class="bi bi-twitter-x"></i></a>
          </div>
        </div>
        <div class="col-6 col-lg-2">
          <h5 class="h6 mb-3">Shop</h5>
          <ul class="list-unstyled small">
            <li class="mb-2"><a href="${base}books.html">All Books</a></li>
            <li class="mb-2"><a href="${base}categories.html">Categories</a></li>
            <li class="mb-2"><a href="${base}cart.html">Cart</a></li>
          </ul>
        </div>
        <div class="col-6 col-lg-2">
          <h5 class="h6 mb-3">Company</h5>
          <ul class="list-unstyled small">
            <li class="mb-2"><a href="${base}about.html">About Us</a></li>
            <li class="mb-2"><a href="${base}contact.html">Contact</a></li>
            <li class="mb-2"><a href="${base}login.html">Login</a></li>
            <li class="mb-2"><a href="${adminLoginHref}">Admin Login</a></li>
          </ul>
        </div>
        <div class="col-lg-4">
          <h5 class="h6 mb-3">Visit the shelf</h5>
          <ul class="list-unstyled small">
            <li class="mb-2"><i class="bi bi-geo-alt me-2"></i>14 Ink Lane, College Road, Ahmedabad</li>
            <li class="mb-2"><i class="bi bi-envelope me-2"></i>hello@bookverse.example</li>
            <li class="mb-2"><i class="bi bi-telephone me-2"></i>+91 98200 00000</li>
          </ul>
        </div>
      </div>
      <div class="fine-print pt-3 mt-4 text-center small">
        <span>&copy; <span id="footerYear"></span> &middot; BookVerse Book Store</span>
      </div>
    </div>
  </footer>
  <button id="backToTop" aria-label="Back to top"><i class="bi bi-arrow-up"></i></button>`;
  const y = document.getElementById("footerYear");
  if (y) y.textContent = new Date().getFullYear();
}

const ADMIN_NAV_LINKS = [
  { href: "dashboard.html", label: "Dashboard", icon: "bi-speedometer2" },
  { href: "add-book.html", label: "Add Book", icon: "bi-plus-square" },
  { href: "manage-books.html", label: "Manage Books", icon: "bi-journal-bookmark" },
  { href: "manage-orders.html", label: "Manage Orders", icon: "bi-bag-check" },
  { href: "manage-users.html", label: "Manage Users", icon: "bi-people" },
  { href: "profile.html", label: "Profile", icon: "bi-person-circle" },
];

function renderAdminShell(activePage) {
  const sidebarMount = document.getElementById("admin-sidebar-placeholder");
  const topbarMount = document.getElementById("admin-topbar-placeholder");
  if (sidebarMount) {
    const links = ADMIN_NAV_LINKS.map(
      (l) => `<a class="nav-link ${activePage === l.href ? "active" : ""}" href="${l.href}">
        <i class="bi ${l.icon}"></i> ${l.label}
      </a>`
    ).join("");
    sidebarMount.innerHTML = `
    <aside class="admin-sidebar" id="adminSidebar">
      <div class="brand d-flex align-items-center justify-content-between">
        <img src="../images/logo-light.svg" alt="BookVerse">
      </div>
      <nav class="d-flex flex-column">${links}</nav>
      <div class="logout-link">
        <a class="nav-link" href="../index.html"><i class="bi bi-box-arrow-left"></i> Logout</a>
      </div>
    </aside>
    <div class="admin-backdrop" id="adminBackdrop"></div>`;
  }
  if (topbarMount) {
    topbarMount.innerHTML = `
    <div class="admin-topbar">
      <div class="d-flex align-items-center gap-3 flex-grow-1">
        <button class="sidebar-toggle-btn" id="sidebarToggleBtn" aria-label="Toggle menu"><i class="bi bi-list"></i></button>
        <div class="topbar-search d-none d-md-block">
          <input type="search" placeholder="Search books, orders, customers...">
          <i class="bi bi-search"></i>
        </div>
      </div>
      <div class="d-flex align-items-center gap-3">
        <button class="notif-btn" aria-label="Notifications">
          <i class="bi bi-bell"></i>
          <span class="cart-badge">3</span>
        </button>
        <button class="admin-user-trigger" type="button">
          <span class="avatar-circle">PA</span>
          <span class="admin-user-meta d-none d-sm-block">
            <span class="name d-block">Priya Admin</span>
            <span class="role d-block">Administrator</span>
          </span>
          <i class="bi bi-chevron-down small text-muted d-none d-sm-inline"></i>
        </button>
      </div>
    </div>`;
  }
  const toggleBtn = document.getElementById("sidebarToggleBtn");
  const sidebar = document.getElementById("adminSidebar");
  const backdrop = document.getElementById("adminBackdrop");
  if (toggleBtn && sidebar && backdrop) {
    toggleBtn.addEventListener("click", () => {
      sidebar.classList.toggle("show");
      backdrop.classList.toggle("show");
    });
    backdrop.addEventListener("click", () => {
      sidebar.classList.remove("show");
      backdrop.classList.remove("show");
    });
  }
}

function activePageTitle(page) {
  const found = ADMIN_NAV_LINKS.find((l) => l.href === page);
  return found ? found.label : "Dashboard";
}

document.addEventListener("DOMContentLoaded", () => {
  renderClientNavbar();
  renderClientFooter();
});
